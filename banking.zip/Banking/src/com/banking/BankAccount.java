package com.banking;

public class BankAccount {
    private int accountId;
    private int customerId;
    private double balance;

    public BankAccount(int accountId, int customerId, double initialBalance) {
        this.accountId = accountId;
        this.customerId = customerId;
        this.balance = initialBalance;
    }

    // Deposit method
    public synchronized void deposit(double amount) {
        balance += amount;
        System.out.println("Deposited " + amount + ", New Balance: " + balance);
    }

    // Withdraw method with exception handling
    public synchronized void withdraw(double amount) throws InsufficientBalanceException {
        if (balance >= amount) {
            balance -= amount;
            System.out.println("Withdrew " + amount + ", New Balance: " + balance);
        } else {
            throw new InsufficientBalanceException("Insufficient balance for withdrawal");
        }
    }

    // Get balance method
    public synchronized double getBalance() {
        return balance;
    }

    public synchronized void transfer(BankAccount targetAccount, double amount) throws InsufficientBalanceException {
        this.withdraw(amount); // Withdraw from current account
        targetAccount.deposit(amount); // Deposit into target account
        System.out.println("Transferred " + amount + " to Account ID: " + targetAccount.accountId);
    }
}

