/**
 * 
 */
/**
 * @author admin
 *
 */
module Banking {
	requires java.sql;
}