
package com.infosys.service;


public class ReportService {
   //Method to display welcome message
	public void display() {
        System.out.println("Hi, Welcome to Report Generation application");
    }
}