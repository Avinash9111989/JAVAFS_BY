package com.infosys.demo;

public interface ReportGenerator {
	
	public String generateReport(int recordsPerPage) throws ReportGeneratorException;
}
