package com.infosys.demo;

public class ReportGeneratorException extends Exception {
	
	private static final long serialVersionUID = 1L;

	ReportGeneratorException(String message)
	{
		super(message);
	}
	
}
