package Exception;

public class ExceptionHandlar extends Exception{
	
	public ExceptionHandlar() {
		// TODO Auto-generated constructor stub
	}
	
	public ExceptionHandlar(String massage) {
		super(massage);
		// TODO Auto-generated constructor stub
	}

}
