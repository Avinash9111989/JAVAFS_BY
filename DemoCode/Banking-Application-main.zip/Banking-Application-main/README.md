# Banking-Application

During my Summer Internship at Zoho Corporation, I had the opportunity to develop a console-based banking application using Core Java and MySQL database.

Features and Banking functionalities included: 
* User/Staff login functionality.
* Creating accounts (savings, current, FD, RD, loan).
* Transfer of funds between accounts.
* Withdrawal of funds from accounts.
* Balance inquiry for accounts.
* Check request capability.
* Account statement generation.
