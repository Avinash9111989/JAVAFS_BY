package com.banking;

public class BankTransaction implements Runnable {
    private BankAccount account;
    private double amount;
    private String operation;

    public BankTransaction(BankAccount account, double amount, String operation) {
        this.account = account;
        this.amount = amount;
        this.operation = operation;
    }

    @Override
    public void run() {
        try {
            if (operation.equals("deposit")) {
                account.deposit(amount);
            } else if (operation.equals("withdraw")) {
                account.withdraw(amount);
            } else {
                System.out.println("Unknown operation.");
            }
        } catch (InsufficientBalanceException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}

