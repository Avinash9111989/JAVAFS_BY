package com.banking;
import java.sql.*;

public class BankingService {
    public static void createAccount(String name, String email, double initialDeposit) {
        String insertCustomerSQL = "INSERT INTO Customers (name, email) VALUES (?, ?)";
        String insertAccountSQL = "INSERT INTO Accounts (customer_id, balance) VALUES (?, ?)";

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement psCustomer = conn.prepareStatement(insertCustomerSQL, Statement.RETURN_GENERATED_KEYS);
             PreparedStatement psAccount = conn.prepareStatement(insertAccountSQL)) {

            // Insert customer
            psCustomer.setString(1, name);
            psCustomer.setString(2, email);
            psCustomer.executeUpdate();

            // Get the generated customer ID
            ResultSet rs = psCustomer.getGeneratedKeys();
            int customerId = 0;
            if (rs.next()) {
                customerId = rs.getInt(1);
            }

            // Insert account
            psAccount.setInt(1, customerId);
            psAccount.setDouble(2, initialDeposit);
            psAccount.executeUpdate();

            System.out.println("Account created successfully for customer ID: " + customerId);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public static void performTransaction(int accountId, String operation, double amount) {
        // Here you would fetch the bank account from the database and perform the operation
        // We will simulate it by assuming a BankAccount object is available.
    }
}

