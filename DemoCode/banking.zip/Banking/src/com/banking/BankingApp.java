package com.banking;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class BankingApp {
    public static void main(String[] args) {
        // Create an account for a customer (for simplicity, using direct values here)
        BankingService.createAccount("John Doe", "john@example.com", 500.0);
        
        // Simulate multiple transactions
        BankAccount account = new BankAccount(1, 1, 500.0); // accountId 1, customerId 1, balance 500.0

        ExecutorService executor = Executors.newFixedThreadPool(3);
        
        // Deposit 200
        executor.submit(new BankTransaction(account, 200, "deposit"));
        
        // Withdraw 100
        executor.submit(new BankTransaction(account, 100, "withdraw"));
        
        // Deposit 150
        executor.submit(new BankTransaction(account, 150, "deposit"));
        
        // Shutdown the executor
        executor.shutdown();
    }
}

