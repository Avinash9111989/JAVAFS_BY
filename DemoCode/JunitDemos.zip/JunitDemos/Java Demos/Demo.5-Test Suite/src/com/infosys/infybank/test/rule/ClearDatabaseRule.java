package com.infosys.infybank.test.rule;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.junit.rules.TestRule;
import org.junit.runner.Description;
import org.junit.runners.model.Statement;

import com.infosys.infybank.core.repository.JDBCUtil;

/**
 * The Class ClearDatabaseRule
 * 
 */
public class ClearDatabaseRule implements TestRule {
	private static final Logger logger = Logger.getLogger(ClearDatabaseRule.class);

	public Statement apply(final Statement base, Description description) {

		return new Statement() {
			@Override
			public void evaluate() throws Throwable {
				logger.debug("Before");
				deleteDatabase();
				base.evaluate();
				logger.debug("After");
			}
		};
	}

	/**
	 * deleting database
	 */
	private void deleteDatabase() {

		Connection jdbcConnection = null;
		PreparedStatement stmt = null;

		try {
			jdbcConnection = JDBCUtil.getConnection();
			jdbcConnection.setAutoCommit(false);
			String delete = "delete FROM ";
			String query = delete + JDBCUtil.getSchema() + " .account_transaction";
			String query1 = delete + JDBCUtil.getSchema() + " .bank_account";
			String query2 = delete + JDBCUtil.getSchema() + " .login";
			String query3 = delete + JDBCUtil.getSchema() + " .customer";

			stmt = jdbcConnection.prepareStatement(query);
			stmt.executeUpdate();
			stmt.close();
			stmt = jdbcConnection.prepareStatement(query1);
			stmt.executeUpdate();
			stmt.close();
			stmt = jdbcConnection.prepareStatement(query2);
			stmt.executeUpdate();
			stmt.close();
			stmt = jdbcConnection.prepareStatement(query3);
			stmt.executeUpdate();
			jdbcConnection.commit();

		} catch (Exception ex) {
			logger.error(ex.getMessage(), ex);
			try {
				if (jdbcConnection != null)
					jdbcConnection.rollback();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
			}
		} finally {
			try {
				if (stmt != null)
					stmt.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(), e);
			}

		}
	}
}
