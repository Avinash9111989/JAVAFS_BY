package com.infosys.infybank.test.rule;

import org.junit.runners.model.Statement;
/**
 * The Class DatabaseStatement
 *
 */
public class DatabaseStatement extends Statement {

	@Override
	public void evaluate() throws Throwable {
		deleteDatabase();
		evaluate();
	}

	private void deleteDatabase() {
		// delete
	}
}
