package com.infosys.infybank.core.service;
import java.util.List;

import com.infosys.infybank.core.dto.LoginDTO;
import com.infosys.infybank.exception.InfyBankServiceException;
import com.infosys.infybank.utilities.RandomPasswordGenerator;
import com.infosys.infybank.utilities.UserProfile;

/**
 * Customer Service class for registeration
 * 
 * @author ETA Java
 * @version 1.0
 */

public class CustomerService {
	private LoginService loginService = new LoginService();

	/**
	 * Creates the user profile.
	 *
	 * @param firstName the first name
	 * @param lastName  the last name
	 * @return the login
	 * @throws InfyBankServiceException the infy bank service exception
	 */
	public LoginDTO createUserProfile(String firstName, String lastName) throws InfyBankServiceException {
		String userIdSuggestion = UserProfile.suggestUserIdFromName(firstName, lastName);
		List<String> userList = loginService.verifyUserNameExistence(userIdSuggestion);
		if (userList != null && !userList.isEmpty())
			userIdSuggestion = UserProfile.createUserId(userList, userIdSuggestion);
		String securePassword = RandomPasswordGenerator.generateHashPswd();

		// return login object
		return new LoginDTO(0, userIdSuggestion, securePassword, 'C', userIdSuggestion);
	}

}
