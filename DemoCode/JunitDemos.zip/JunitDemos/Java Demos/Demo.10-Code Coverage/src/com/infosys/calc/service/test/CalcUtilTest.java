package com.infosys.calc.service.test;

import static org.junit.Assert.assertSame;

import org.junit.Assert;
import org.junit.Test;

import com.infosys.calc.service.CalcUtil;

public class CalcUtilTest {
	
	@Test
	public void testCalc(){
		CalcUtil cal = new CalcUtil();
		int z = cal.calculate(2, 1);
		Assert.assertEquals(2, z);
		String s=cal.display();
		assertSame("In display", s);
	}
	@Test
	public void testCalcForZeroX(){
		CalcUtil cal = new CalcUtil();
		int z = cal.calculate(0, 1);
		Assert.assertEquals(1, z);
	}	
	
	@Test
	public void testCalcForZeroY(){
		CalcUtil cal = new CalcUtil();
		int z = cal.calculate(1, 0);
		Assert.assertEquals(1, z);
	}
}
