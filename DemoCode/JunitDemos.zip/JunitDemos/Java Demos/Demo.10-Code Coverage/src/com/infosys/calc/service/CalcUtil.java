package com.infosys.calc.service;

public class CalcUtil {
	String str="In display";
 	public int calculate(int x, int y) {
		int z = 0;
		if ((x > 0) && (y > 0)) {
			z = x * y;
		} else {
			z = x + y;
		}
		return z;
	}
	public String display(){
		return str;
	}
}

