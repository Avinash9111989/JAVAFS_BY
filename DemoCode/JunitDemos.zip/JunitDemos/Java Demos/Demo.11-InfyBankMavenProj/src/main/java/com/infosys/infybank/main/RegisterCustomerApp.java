package com.infosys.infybank.main;

import java.math.BigDecimal;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

import org.apache.log4j.Logger;
import com.infosys.infybank.core.dto.RegistrationDTO;
import com.infosys.infybank.core.service.CustomerService;
import com.infosys.infybank.exception.InfyBankServiceException;

public class RegisterCustomerApp {
	private static final Logger logger = Logger.getLogger(RegisterCustomerApp.class);
	public static void main(String[] args) {
		RegisterCustomerApp rcust = new RegisterCustomerApp();
		
		Scanner sc = new Scanner(System.in);
		logger.info("1: Register new Custmer\n" + "2: Exit");
		logger.info("Enter your choice:");
		int ch = sc.nextInt();
		while (ch!=2) {
			
			switch (ch) {
			case 1:
				rcust.captureInput();
				break;
			case 2:
				System.exit(1);
				break;
			default:
				logger.info("Wrong choice enterered.Enter your choice again");
				ch = sc.nextInt();
				break;
			}
			sc.close();
		}
	}
	
private void captureInput() {
		
		RegistrationDTO dto = new RegistrationDTO();
		Scanner sc = new Scanner(System.in);
		logger.info("Enter below details to Register New Customer");
		logger.info("Enter First name:");
		String fname = sc.next();
		dto.setFirstName(fname);
		logger.info("Enter Last name:");
		String lname = sc.next();
		dto.setLastName(lname);
		logger.info("Enter PAN details:");
		String pan = sc.next();
		dto.setPanNo(pan);
		logger.info("Enter Aadhar id:");
		String adharId = sc.next();
		dto.setAadharId(adharId);
		logger.info("Enter Email ID:");
		String email = sc.next();
		dto.setEmailId(email);
		logger.info("Enter Customer DOB (dd-MM-yyyy)");
		String dob = sc.next();
		// String DOB to Date
		java.util.Date dobl;
		try {
			dobl = new SimpleDateFormat("dd-MM-yyyy").parse(dob);

			dto.setDob(dobl);
		} catch (ParseException e1) {
			logger.error(e1.getMessage());
			}

		logger.info("Enter Address:");
		String add = sc.next();
		dto.setAddress(add);
		logger.info("Enter City:");
		String city = sc.next();
		dto.setCity(city);
		logger.info("Enter Pincode:");
		String pin = sc.next();
		dto.setPincode(pin);
		logger.info("Enter State:");
		String state = sc.next();
		dto.setState(state);
		logger.info("Enter Account Type:(For Current Account:C / For Savings: S)");
		String accType = sc.next();
		dto.setAcctType(accType);
		logger.info("Enter amount to be deposited");
		BigDecimal amt = sc.nextBigDecimal();
		dto.setBalance(amt);
	
		logger.info("You want to make this account Salaried? Y/N");
		String salr = sc.next();
		dto.setSalaried(salr);

		CustomerService service = new CustomerService();
		try {
			service.registerCustomer(dto);
			logger.debug("Customer Registered sucessfully! Your loginId and password details will be sent to your mail");
		} catch (InfyBankServiceException e) {
			logger.error(e.getMessage() + ". Please try again");
		}
		finally{
			sc.close();
		}
	}

}
