package com.infosys.infybank.core.service.test;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ErrorCollector;
import org.junit.rules.TemporaryFolder;
import org.junit.rules.TestName;
import org.junit.rules.Timeout;

import com.infosys.infybank.core.dto.RegistrationDTO;
import com.infosys.infybank.core.service.CustomerService;
import com.infosys.infybank.exception.InfyBankServiceException;
import com.infosys.infybank.test.utility.XMLUtil;

/**
 * The Class RuleDemo
 */
public class RuleDemo {
	private static final Logger logger = Logger.getLogger(RuleDemo.class);
	/**
	 * Rule Test name
	 */
	@Rule
	public TestName name = new TestName();

	/**
	 * Rule TemporaryFolder
	 */
	@Rule
	public TemporaryFolder temporaryFolder = new TemporaryFolder();

	/**
	 * Rule Timeout
	 */
	@Rule
	public Timeout timeout = new Timeout(1000, TimeUnit.MILLISECONDS);

	/**
	 * Rule ErrorCollector
	 */
	@Rule
	public ErrorCollector collector = new ErrorCollector();

	/**
	 * prints first name
	 */
	@Test
	public void firstTest() {
		logger.info(name.getMethodName());// Will print firstTest in
		// console
	}

	/**
	 * @throws IOException
	 */
	@Test
	public void testRun() throws IOException {
		temporaryFolder.newFile("myfile.txt");
		File createdFolder = temporaryFolder.newFolder("subfolder");
		// code to test the methods
		assertTrue(temporaryFolder.newFolder().exists());
		assertTrue(createdFolder.exists());
	}

	/**
	 * @throws InfyBankServiceException
	 */
	@Test
	public void testRegisterCustomerValidSuccess() throws InfyBankServiceException {
		RegistrationDTO dto = (RegistrationDTO) XMLUtil.getObject("ValidCustomer.xml", RegistrationDTO.class);
		CustomerService service = new CustomerService();
		assertTrue(service.registerCustomer(dto));

	}

	/**
	 * 
	 */
	@Test
	public void testSomething() {
		collector.addError(new Throwable("First thing  wrong"));
		collector.addError(new Throwable("Second thing wrong"));
		 doStuff();
		}

	/**
	 * @return
	 */
	String stuff="Oh, not again an error";
	private String doStuff() {
		return stuff;
	}

}
