package com.infosys.infybank.test.category;

/**
 * The Interface InvalidCategory
 *
 */
public interface InvalidCategory {

}
