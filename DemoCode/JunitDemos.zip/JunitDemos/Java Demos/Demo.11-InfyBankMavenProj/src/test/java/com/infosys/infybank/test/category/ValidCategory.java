package com.infosys.infybank.test.category;

/**
 * The Interface ValidCategory
 *
 */
public interface ValidCategory {

}
