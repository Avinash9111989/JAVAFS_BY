package com.infosys.infybank.core.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.infosys.infybank.core.dto.LoginDTO;

/**
 * The Class LoginRepository.
 */

public class LoginRepository {
	
	private static final Logger logger = Logger.getLogger(LoginRepository.class);
	
	/**
	 * Find user having user name like.
	 *
	 * @param userId
	 *            the user id
	 * @return the list
	 */
	public List<String> findUserHavingUserNameLike(String userId) {
		List<String> lstUserId = new ArrayList<>();
		Connection jdbcConnection = null;
		ResultSet rs = null;
		jdbcConnection = JDBCUtil.getConnection();
		String query = "SELECT user_id  FROM  " + JDBCUtil.schema + ".login where user_Id like ?";
		
		try(PreparedStatement stmt = jdbcConnection.prepareStatement(query);) {
			
			stmt.setString(1, userId + "%");
			rs = stmt.executeQuery();
			while (rs.next()) {
				lstUserId.add(rs.getString(1));
			}

		} catch (SQLException ex) {
			logger.error(ex.getMessage(),ex);
		} finally {

			try {
				if (rs != null)
					rs.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(),e);
			}

		}
		return lstUserId;
	}

	public void save(LoginDTO loginDTO) {
		String query = "insert into  " + JDBCUtil.schema + ".login values(?,?,?,?,?,?)";
		Connection jdbcConnection = null;
		PreparedStatement stmt = null;

		try {

			jdbcConnection = JDBCUtil.getConnection();
			stmt = jdbcConnection.prepareStatement(query);
			stmt.setInt(1, loginDTO.getCustId());
			stmt.setString(2, loginDTO.getLstUpdtId());
			stmt.setObject(3, loginDTO.getLstUpdtTs());
			stmt.setString(4, loginDTO.getPassword());
			stmt.setString(5, Character.toString(loginDTO.getRole()));
			stmt.setString(6, loginDTO.getUserId());

			stmt.executeUpdate();

		} catch (SQLException ex) {
			logger.error(ex.getMessage(),ex);
		} finally {

			try {
				if (stmt != null)
					stmt.close();
			} catch (SQLException e) {
				logger.error(e.getMessage(),e);
			}

		}

	}

}
