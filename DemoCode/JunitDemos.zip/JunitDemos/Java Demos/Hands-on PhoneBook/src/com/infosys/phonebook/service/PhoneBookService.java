package com.infosys.phonebook.service;

import java.util.List;

import org.apache.log4j.Logger;

import com.infosys.phonebook.Country;
import com.infosys.phonebook.formatter.FormatterFactory;
import com.infosys.phonebook.formatter.IPhoneFormatter;
import com.infosys.phonebook.repository.PhoneRepository;
import com.infosys.phonebook.vo.SearchResult;
/**
 * @author ETA
 *The Class PhoneBookService
 */
public class PhoneBookService {
	static final Logger logger = Logger.getLogger(PhoneBookService.class);
	/**
	 * 
	 */
	PhoneRepository phoneRepository = new PhoneRepository();

	/**
	 * @param searchString
	 * @param country
	 * @return
	 */
	public List<SearchResult> search(String searchString, String country) {
		List<SearchResult> retList = phoneRepository.find(searchString, country);
		if (!retList.isEmpty()) {
			IPhoneFormatter phoneFormatter = FormatterFactory.getFormatter(Country.valueOf(country.toUpperCase()));
			for (SearchResult searchResult : retList) {
				String phone = phoneFormatter.formatPhoneNo(searchResult.getPhoneNo());
				searchResult.setPhoneNo(phone);

			}
		}

		return retList;
	}

	/*public static void main(String[] args) {
		PhoneBookService srv = new PhoneBookService();
		List resultLst = srv.search("Jo", "USA");
		resultLst.forEach((x) -> System.out.println(x));

	}*/
}
