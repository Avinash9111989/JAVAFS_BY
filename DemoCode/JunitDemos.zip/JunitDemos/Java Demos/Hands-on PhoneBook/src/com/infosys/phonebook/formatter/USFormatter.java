package com.infosys.phonebook.formatter;

import com.infosys.phonebook.InvalidInputException;
/**
 * @author ETA
 *
 */
public class USFormatter implements IPhoneFormatter {

	@Override
	public String formatPhoneNo(String input) {
		StringBuilder formatted = new StringBuilder(input);
		formatted = formatted.insert(0, "+1(");
		formatted = formatted.insert(6, ")");
		formatted = formatted.insert(10, "-");
		return formatted.toString();

	}

	@Override
	public boolean validatePhoneLength(String input) throws InvalidInputException {
		if (input.length() != 9) {
			throw new InvalidInputException("Input should contain "
					+ "only numbers with 9 digits");

		}
		return true;
	}

}
