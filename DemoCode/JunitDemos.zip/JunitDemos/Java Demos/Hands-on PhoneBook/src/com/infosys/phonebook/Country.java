package com.infosys.phonebook;

/**
 * @author ETA Enum for Country
 *
 */
public enum Country {
	USA, INDIA
}
