package com.infosys.phonebook.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.infosys.phonebook.vo.SearchResult;
/**
 * @author ETA
 *The Class PhoneRepository
 */
public class PhoneRepository {
	static final Logger logger = Logger.getLogger(PhoneRepository.class);
	/**
	 * @param searchString
	 * @param country
	 * @return
	 */
	public List<SearchResult> find(String searchString, String country) {

		List<SearchResult> result = new ArrayList<>();
		String query = "SELECT EMPID,FIRST_NAME, LAST_NAME,PHONE_NO,DEPARTMENT,COUNTRY FROM " + JDBCUtil.SCHEMA
				+ ".employee_phonebook  where upper(country) = ? and (empid = ? or upper(first_name) like ? or upper(last_name) like ?"
				+ " or PHONE_NO = ? or upper(DEPARTMENT) like ?)";
		try(Connection jdbcConnection = JDBCUtil.getConnection();
			PreparedStatement stmt = jdbcConnection.prepareStatement(query);){
			System.out.println(query);
			stmt.setString(1, country.toUpperCase());
			stmt.setString(2, searchString);
			stmt.setString(3, "%" + searchString.toUpperCase() + "%");
			stmt.setString(4, "%" + searchString.toUpperCase() + "%");
			stmt.setString(5, searchString);
			stmt.setString(6, "%" + searchString.toUpperCase() + "%");
			try(ResultSet rs = stmt.executeQuery();){
				while (rs.next()) {
					SearchResult dto = new SearchResult();
					dto.setEmpId((rs.getInt(1)));

					dto.setFirstName(rs.getString(2));
					dto.setLastName(rs.getString(3));
					dto.setPhoneNo(rs.getString(4));

					dto.setDepartment(rs.getString(5));

					dto.setCountry(rs.getString(6));

					result.add(dto);
				
			}
			
			}

		} catch (Exception ex) {
			logger.error(ex.getMessage(),ex);
		}
		return result;
	}
}
