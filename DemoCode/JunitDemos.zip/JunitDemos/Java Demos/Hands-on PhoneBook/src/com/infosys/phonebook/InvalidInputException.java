package com.infosys.phonebook;
/**
 * @author ETA
 *
 */
public class InvalidInputException extends Exception {

	/**
	 * @param msg
	 */
	public InvalidInputException(String msg) {
		super(msg);
	}

}
