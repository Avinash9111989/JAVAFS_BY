package com.infosys.phonebook.formatter;

import com.infosys.phonebook.Country;
/**
 * @author ETA
 *
 */
public class FormatterFactory {
	private FormatterFactory() {
		
	}

	/**
	 * @param country
	 * @return
	 */
	public static IPhoneFormatter getFormatter(Country country) {
		IPhoneFormatter formatter = null;
		if(Country.USA==country) {
			formatter = new USFormatter();
		}
		else if(Country.INDIA==country) {
			formatter = new IndianFormatter();
		}

		return formatter;
	}
}
