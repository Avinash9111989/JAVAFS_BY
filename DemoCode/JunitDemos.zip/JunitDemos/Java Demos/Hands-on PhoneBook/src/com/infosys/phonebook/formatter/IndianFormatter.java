package com.infosys.phonebook.formatter;

import com.infosys.phonebook.InvalidInputException;
/**
 * @author ETA
 *
 */
public class IndianFormatter implements IPhoneFormatter {

	@Override
	public String formatPhoneNo(String input) {
		StringBuilder formatted = new StringBuilder(input);
		formatted = formatted.insert(0, "+91");
		return formatted.toString();

	}

	@Override
	public boolean validatePhoneLength(String input) throws InvalidInputException {
		if (input.length() != 10) {
			throw new InvalidInputException("Input should contain "
					+ "only numbers with 10 digits");

		}
		return true;
	}

}
