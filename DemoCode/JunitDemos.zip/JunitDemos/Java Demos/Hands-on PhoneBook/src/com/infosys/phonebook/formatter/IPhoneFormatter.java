package com.infosys.phonebook.formatter;

import java.util.regex.Pattern;

import com.infosys.phonebook.InvalidInputException;
/**
 * @author ETA
 *
 */
public interface IPhoneFormatter {
	/**
	 * @param input
	 * @return
	 */
	public String formatPhoneNo(String input);

	/**
	 * @param input
	 * @return
	 * @throws InvalidInputException
	 */
	public boolean validatePhoneLength(String input) throws InvalidInputException;

	/**
	 * @param input
	 * @throws InvalidInputException
	 */
	default void validatePhone(String input) throws InvalidInputException {
		
		if (input == null || input.trim().length() == 0) {
			throw new InvalidInputException("Input is required");
		}
		System.out.println("pattern" + Pattern.matches("[0-9]+", input));

		if (!Pattern.matches("[0-9]+", input)) {
			throw new InvalidInputException("Input should contain only numbers");
		}
		validatePhoneLength(input);

	}

}
