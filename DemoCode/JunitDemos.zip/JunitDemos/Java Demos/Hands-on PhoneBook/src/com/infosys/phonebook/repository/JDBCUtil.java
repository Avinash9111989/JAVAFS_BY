package com.infosys.phonebook.repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.infosys.phonebook.util.PropertyUtil;
/**
 * @author ETA
 * The Class JDBCUtil
 *
 */
public class JDBCUtil {
	private JDBCUtil() {
		
	}
	static final Logger logger = Logger.getLogger(JDBCUtil.class);
	public static String SCHEMA;
	private static Connection jdbcConnection = null;
	/**
	 * @return
	 * @throws Exception
	 */
	public static Connection getConnection() throws Exception {

		if (jdbcConnection == null) {
			Properties prop = PropertyUtil.getProperties();
			SCHEMA = prop.getProperty("SCHEMA");
			Class.forName(prop.getProperty("JDBC_DRIVER"));
			jdbcConnection = DriverManager.getConnection(prop.getProperty("JDBC_URL"), prop.getProperty("USER"),
					prop.getProperty("PASSWORD"));
			jdbcConnection.setAutoCommit(false);

		}

		return jdbcConnection;
	}

	public static void closeConnection() {
		if (jdbcConnection != null) {
			try {
				jdbcConnection.close();
				jdbcConnection = null;
			} catch (SQLException e) {
				logger.error(e.getMessage(),e);
			}
		}

	}

	public static void commit() {
		try {
			jdbcConnection.commit();
		} catch (SQLException e) {
			logger.error(e.getMessage(),e);
		}

	}

	public static void rollback() {
		try {
			jdbcConnection.rollback();
		} catch (SQLException e) {
			logger.error(e.getMessage(),e);
		}
	}
}
