package com.infosys.infybank.test.category;

public interface InvalidCategory {

}
