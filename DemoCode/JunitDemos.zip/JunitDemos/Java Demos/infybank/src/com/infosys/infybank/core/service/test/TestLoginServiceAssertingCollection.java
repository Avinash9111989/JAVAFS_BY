package com.infosys.infybank.core.service.test;

import static org.junit.Assert.assertThat;

import java.util.List;
import static org.hamcrest.CoreMatchers.hasItems;
import static org.hamcrest.CoreMatchers.is;

import org.junit.Test;

import com.infosys.infybank.core.service.LoginService;

public class TestLoginServiceAssertingCollection {

	private LoginService loginService = new LoginService();
	String username="rajasing";
	@Test
	public void verifyUserNameExistencelist2() {
		List<String> lstUserId = loginService.verifyUserNameExistence(username);
		assertThat(lstUserId, hasItems(username));
	}

	@Test
	public void verifyUserNameExistencelist3() {
		 List<String> lstUserId = loginService.verifyUserNameExistence(username);
		assertThat(lstUserId.size(), is(1));
	}

}
