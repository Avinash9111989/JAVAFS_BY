package com.infosys.infybank.core.service.test;

import org.junit.Assert;
import org.junit.Test;

public class CalcUtilTest {
	CalcUtil tc= new CalcUtil();
	 char value;
	 @Test
	 public void testdispaly(){
	     value = tc.display(64);
	     Assert.assertSame(value, 'F');
	     value = tc.display(93);
	     Assert.assertSame(value, 'A');
	     value = tc.display(70);
	     Assert.assertSame(value, 'B');
	     value = tc.display(100);
	     Assert.assertSame(value, 'F');
	 }
}
