package com.infosys.infybank.core.service.test;

import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.junit.AfterClass;

import org.junit.BeforeClass;
import org.junit.Test;

import com.infosys.infybank.core.dto.RegistrationDTO;
import com.infosys.infybank.core.service.CustomerService;
import com.infosys.infybank.exception.InfyBankServiceException;

public class TestCustomerServiceFixture {
	private static RegistrationDTO dto;
	private static CustomerService service;

	@BeforeClass
	public static void setup() throws ParseException {
		dto = new RegistrationDTO();
		service = new CustomerService();
		dto.setAadharId("201123203477");
		dto.setAcctType("C");
		dto.setAddress("Jamshedpur");
		dto.setBalance(new BigDecimal(5000));
		dto.setCity("Jamshedpur");
		dto.setDob(new SimpleDateFormat("dd-MM-yyyy").parse("12-12-2000"));
		dto.setEmailId("rajan100@gmail.com");
		dto.setFirstName("Rajan1");
		dto.setLastName("Singh1");
		dto.setPanNo("AHWBW4567Z");
		dto.setPincode("599456");
		dto.setSalaried("Y");
		dto.setState("Gujarat");
	}

	@Test(expected=InfyBankServiceException.class)
	public void testRegisterCustomerValid() throws InfyBankServiceException  {
		assertTrue(service.registerCustomer(dto));
	}


	@AfterClass
	public static void destroyInput() {
		dto = null;
		service = null;
	}
}